<?php
use App\FactoryOrder\Tools;

class GetMenu
{
    public function getFoods($text)
    {
        $tools = new Tools();
        $yummy = json_decode($text);


        $data = [];

        foreach($yummy->recipes as $mydata)
        {
            if(!$tools->isExpire() && $tools->inStock())
                if($tools->BestBefore() != ''){
                    $data['title_bestbefore'] = $mydata->title;
                }
            $data['title'] = $mydata->title;
            foreach($mydata->ingredients as $value)
            {
                if(!$tools->isExpire() && $tools->inStock())
                    $data['ingredients'] = $value;
            }
        }
        return $data;
    }
}
