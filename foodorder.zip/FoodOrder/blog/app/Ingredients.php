<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ingredients extends Model
{
    protected $fillable = [
        'title', 'best_before', 'expires-at','stock'
    ];
}
