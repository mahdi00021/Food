<?php

$text = '{
	"recipes": [{
		"title": "Ham and Cheese Toastie",
		"ingredients": [
			"Ham",
			"Cheese",
			"Bread",
			"Butter"
		]
	}, {
		"title": "Fry-up",
		"ingredients": [
			"Bacon",
			"Eggs",
			"Baked Beans",
			"Mushrooms",
			"Sausage",
			"Bread"
		]
	}, {
		"title": "Salad",
		"ingredients": [
			"Lettuce",
			"Tomato",
			"Cucumber",
			"Beetroot",
			"Salad Dressing"
		]
	}, {
		"title": "Hotdog",
		"ingredients": [
			"Hotdog Bun",
			"Sausage",
			"Ketchup",
			"Mustard"
		]
	}]
}';

$yummy = json_decode($text);
$input ='Hotdog';

foreach($yummy->recipes as $mydata)
{
    if($mydata->title == $input)
        echo $mydata->title ."\n";
    foreach($mydata->ingredients as $values)
    {
        if($mydata->title == $input)
        echo $values . "\n";
    }
}




