**This system first get request post then using from that in classes
for example : when time get rquest post "salad" first does search in json text in controller 
then if has been avalible will select of database and doing other actions **

*for using of system 
first must:
read file web.php in path route
then you can going to include class and using of thats

**System includes of : factory pattern for make each class food like as salad

*for install sql 
import sql file into mysql
we dont using of migrate in laravel
