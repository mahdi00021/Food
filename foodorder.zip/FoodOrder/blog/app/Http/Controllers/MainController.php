<?php
namespace App\FactoryOrder;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;

class MainController extends BaseController
{
    /**
     * GET menu list food if Available
     *
     * @return array
    */
    public function menu()
    {
      $factoryGet = new \GetMenu();

      $text = '{
        "recipes": [{
            "title": "Ham and Cheese Toastie",
            "ingredients": [
                "Ham",
                "Cheese",
                "Bread",
                "Butter"
            ]
        }, {
            "title": "Fry-up",
            "ingredients": [
                "Bacon",
                "Eggs",
                "Baked Beans",
                "Mushrooms",
                "Sausage",
                "Bread"
            ]
        }, {
            "title": "Salad",
            "ingredients": [
                "Lettuce",
                "Tomato",
                "Cucumber",
                "Beetroot",
                "Salad Dressing"
            ]
        }, {
            "title": "Hotdog",
            "ingredients": [
                "Hotdog Bun",
                "Sausage",
                "Ketchup",
                "Mustard"
            ]
        }]
    }';
       return $factoryGet->getFoods($text);
    }


    /**
     * Order food if Available for example in post request is : Salad
     * and factory method make this class for Salad
     * @param Request $request
     * @return mixed
     * @throws \Exception
    */
    public function order(Request $request)
    {
       $factory = new FactoryMain();
       return $factory->mainFactory($request->post('class_food'));
    }
}
