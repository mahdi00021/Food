<?php

namespace App\FactoryOrder;

/**
 * Class Salad
 * @package App\FactoryOrder
*/
class Salad implements IShow
{

    /**
     * this method for show food salad details
     * @param $text
     * @param $inputOrder
     * @return array
    */
    public function show($text,$inputOrder)
    {
        $tools = new Tools();
        $yummy = json_decode($text);
        $input = $inputOrder;

        $data = [];

        foreach($yummy->recipes as $mydata)
        {
            if($mydata->title == $input && !$tools->isExpire() && $tools->inStock())
                if($tools->BestBefore() != ''){
                    $data['title_bestbefore'] = $mydata->title;
                }
            $data['title'] = $mydata->title;
            $tools->decrease( $tools->getId($mydata->title) );
            foreach($mydata->ingredients as $value)
            {
                if($mydata->title == $input && !$tools->isExpire() && $tools->inStock())
                    $data['ingredients'] = $value;
            }
        }
        return $data;
    }
}
