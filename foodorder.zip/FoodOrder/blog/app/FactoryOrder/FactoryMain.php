<?php
namespace App\FactoryOrder;


use App\Ingredients;
use Illuminate\Console\Scheduling\Schedule;

/*
 * class Factory Main is for create instance for classes
*/
class FactoryMain
{
    public function mainFactory($class_food)
    {
        $schedule = new Schedule();
        $schedule->call(function () {
            $inStock = Ingredients::select('stock')
                ->where('stock', '=', '0')
                ->get()
                ->increment('stock',4);
            return $inStock;
        })->everyFifteenMinutes();

        $formatterClass = __NAMESPACE__ . ucfirst($class_food);
        if (!class_exists($formatterClass)) {
            throw new \Exception("Unknown report class $class_food");
        }
        return new $formatterClass->show();
    }
}
