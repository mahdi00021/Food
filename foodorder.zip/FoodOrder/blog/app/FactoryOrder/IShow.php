<?php

namespace App\FactoryOrder;

/**
 * Interface IShow for using in factory classes
 * @package App\FactoryOrder
*/
interface IShow
{
    public function show($text,$inputOrder); //show foods details
}
