<?php
namespace App\FactoryOrder;

use App\Ingredients;
use Carbon\Carbon;
use App\FactoryOrder;

/*
 * class foe create foods like as Fry_up
*/
class Fry_up implements IShow
{

    /**
     * This method show food if has Available
     * @param $text
     * @param $inputOrder
     * @return array
     */
    public function show($text,$inputOrder)
    {
        $tools = new Tools();
        $yummy = json_decode($text);
        $input = $inputOrder;

        $data = [];

        foreach($yummy->recipes as $mydata)
        {
            if($mydata->title == $input && !$tools->isExpire() && $tools->inStock())
                if($tools->BestBefore() != ''){
                  $data['title_bestbefore'] = $mydata->title;
                }
                $data['title'] = $mydata->title;
                $tools->decrease( $tools->getId($mydata->title) );
            foreach($mydata->ingredients as $value)
            {
                if($mydata->title == $input && !$tools->isExpire() && $tools->inStock())
                    $data['ingredients'] = $value;
            }
        }
        return $data;
    }



}
