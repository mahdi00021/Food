<?php
namespace App\FactoryOrder;

use App\Ingredients;
use Carbon\Carbon;

/**
 * Class Tools is for using of like as facade for using in classes
 * this class have tools for get data of database
 * @package App\FactoryOrder
*/
class Tools
{

    /**
     * if foods has been Expire return true or false
     * @return bool
    */
    public function isExpire()
    {
        $now = Carbon::now();
        $foods_Expired = Ingredients::select('title')
            ->groupBy('expires-at')
            ->whereDate('expires-at', '<', $now->toDateString())
            ->get();
        if($foods_Expired == '') return true;
        else return false;
    }

    /**
     * if foods has been BestBefore return data of that
     * @return mixed
    */
    public function BestBefore()
    {
        $now = Carbon::now();
        $Best_Before = Ingredients::select('title')
            ->groupBy('best_before')
            ->whereDate('best_before', '<', $now->toDateString())
            ->get();
        return $Best_Before;

    }

    /**
     * if foods Available in Stock return true or false
     * @return bool
    */
    public function inStock()
    {
        $inStock = Ingredients::select('stock')
            ->where('stock', '=', '0')
            ->get();
        if($inStock =='') return false;
        else return true;
    }

    /**
     * if order is successful Then must decrease of field stock 1 unit
     * @param $id
     * @return bool
    */
    public function decrease($id)
    {
        $foods_decrease = Ingredients::find($id)->decrement('stock',1);
        if($foods_decrease)
            return true;
        else
            return false;
    }

    /**
     * this method is for get id - get title and get id of food
     * @param $title
     * @return mixed
    */
    public function getId($title)
    {
        $id = Ingredients::find($title)->get();
        return $id;
    }
}
